package com.example.semyo.fromdptopix;

/*В данном случае создается 2 элемента TextView. Для установки высоты для обоих элементов используется
значение из переменной textViewHeight, однако в первом случае это значение подвергается преоразованию
из dp в пиксели, и соответственно оба элемента будут иметь различную итоговую высоту*/

import android.app.Activity;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // условное значение в dp
        int textViewHeight = 100;

        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        TextView textView1 = new TextView(this);
        textView1.setText("Hello Android Nougat!");
        textView1.setTextSize(26);
        textView1.setBackgroundColor(0xffc5cae9);

        // преобразуем размер из dp в физические пиксели
        int height = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                textViewHeight, getResources().getDisplayMetrics());
        textView1.setHeight(height);

        linearLayout.addView(textView1);

        TextView textView2 = new TextView(this);
        textView2.setText("Hello Android Nougat!");
        textView2.setTextSize(26);
        textView2.setBackgroundColor(0xffbbdefb);
        textView2.setHeight(textViewHeight);

        linearLayout.addView(textView2);

        setContentView(linearLayout);
    }
}
